// create the demo namespace
window.demo= 
{
	AppConstants: 
	{
		/**
		 * A notification that will trigger StartupCommand
		 */
		STARTUP: 'startup',			
		
		/**
		 * A notification that will trigger ProcessTextCommand
		 */
		PROCESS_TEXT: 'processText',

		/**
		 * A notification that that
		 */
		PALINDROME_DETECTED: 'palindromeDetected'
	}
};
